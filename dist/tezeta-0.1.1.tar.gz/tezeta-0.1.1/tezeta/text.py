def fit_text():
    return ""